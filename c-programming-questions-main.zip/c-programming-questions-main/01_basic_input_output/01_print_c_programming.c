// // C program to print C Programming on screen

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf("C Programming"); // // printf() function is used to print Output on screen

    getch();
    return 0;
}
// // Main Function End