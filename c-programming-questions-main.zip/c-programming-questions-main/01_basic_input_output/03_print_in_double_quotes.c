// // C program to print "C Programming" in Double Quotes

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" \"C Programming\" "); // // '\"' is used to print Double Quotes (")

    getch();
    return 0;
}
// // Main Function End