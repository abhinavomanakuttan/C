// // C program to print New line character '\n' on screen.
// // 👉 Output => \n

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" \\n ");

    getch();
    return 0;
}
// // Main Function End