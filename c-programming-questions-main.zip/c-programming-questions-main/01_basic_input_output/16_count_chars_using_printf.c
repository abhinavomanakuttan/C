// // C program to count number of characters in this string => “C Programming” using printf() function. 


// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    int numberOfChars;
    numberOfChars = printf("C Programming");
    printf("\nNumber of Characters in \"C Programming\" => %d", numberOfChars);

    getch();
    return 0;
}
// // Main Function End