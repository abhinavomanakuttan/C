// // C program to print following String :-
// // 👉 Output => " Hello, this is forward slash (/) , this is back slash (\) , this is single quote (') and this is double quotes (") "

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" \"Hello, this is  forward slash (/), this is back slash (\\), this is single quote (') and this is double quote (\") ");

    getch();
    return 0;
}
// // Main Function End