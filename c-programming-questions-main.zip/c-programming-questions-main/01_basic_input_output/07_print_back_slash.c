// // C program to print single Back Slash (\) on screen
// // 👉 Output => \

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" \\ ");

    getch();
    return 0;
}
// // Main Function End
