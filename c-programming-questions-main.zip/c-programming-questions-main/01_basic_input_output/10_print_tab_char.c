// // C program to print Tab character '\t' on screen.
// // 👉 Output => \t

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" \\t ");

    getch();
    return 0;
}
// // Main Function End