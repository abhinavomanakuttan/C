// // C program to print "C Programming" in Single Quotes

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" 'C Programming' ");

    getch();
    return 0;
}
// // Main Function End