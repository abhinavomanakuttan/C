// // C program to print C in first line and Programming in the second line.

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf("C\nProgramming"); // // '\n' is used to add New line.

    getch();
    return 0;
}
// // Main Function End