// // C program to print (%d) on screen
// // 👉 Output => %d

// // Header files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf(" %%d ");

    getch();
    return 0;
}
// // Main Function End