// // C program to print C-Programming 10 times on the screen

// // Header Files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf("\n>>>>>>>> C-Programming 10 Times <<<<<<<<\n");

    // // 1st Approach (using while loop)
    int i = 0;
    while (i < 10)
    {
        printf("\nC-Programming");
        i++;
    }

    // // 2nd Approach (using while loop)
    // // int i = 0;
    // // while (i++ < 10)
    // //    printf("\nC-Programming");

    // // 3rd Approach (using do-while loop)
    // // int i = 0;
    // // do
    // // {
    // //    printf("\nC-Programming");
    // //    i++;
    // // } while (i < 10);

    // // 4th Approach (using do-while loop)
    // // int i = 0;
    // // do
    // // {
    // //    printf("\nC-Programming");
    // // } while (++i < 10);

    // // 5th Approach (using for loop)
    // // for (int i = 0; i < 10; i++)
    // //    printf("\nC-Programming");

    printf("\n");
    getch();
    return 0;
}
// // Main Function End
