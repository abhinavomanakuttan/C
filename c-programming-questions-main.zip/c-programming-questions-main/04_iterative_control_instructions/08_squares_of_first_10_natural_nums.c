// // C program to print squares of the first 10 natural numbers

// // Header Files
#include <stdio.h>
#include <conio.h>

// // Main Function Start
int main()
{

    printf("\n>>>>>>>>> Squares of First 10 Natural Numbers <<<<<<<<<\n");

    // // 1st Approach (using while loop)
    int i = 1;
    while (i <= 10)
    {
        printf("\n%d", i * i);
        i++;
    }

    // // 2nd Approach (using while loop)
    // // int i = 0;
    // // while (i++ < 10)
    // //    printf("\n%d", i*i);

    // // 3rd Approach (using do-while loop)
    // // int i = 1;
    // // do
    // // {
    // //    printf("\n%d", i*i);
    // //    i++;
    // // } while (i <= 10);

    // // 4th Approach (using do-while loop)
    // // int i = 0;
    // // do
    // // {
    // //    printf("\n%d", (i + 1) * (i + 1));
    // // } while (++i < 10);

    // // 5th Approach (using for loop)
    // // for (int i = 1; i <= 10; i++)
    // //    printf("\n%d", i*i);

    printf("\n");
    getch();
    return 0;
}
// // Main Function End
